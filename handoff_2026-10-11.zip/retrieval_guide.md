# Retrieval guide — files for Jenna to fetch

Sites that blocked automated reading but open normally in a browser. For each: the link, the exact file, and the clicks. Save everything into one folder (e.g. `sources_fetched/`) and attach or connect it.

Status 11 Oct 2026: ✅ done and folded into the register · ⏳ requested / in progress · ☐ still to do · ◇ optional.

## Done
- ✅ A1 CWEC typical-year files, Vancouver Intl and Edmonton Intl (`CWEC_FMCCE_v_2020`) → data/, `free_cooling_hours` and `demand_profile` computed.
- ✅ A2 Climate Normals 1991–2020, BC and AB CSVs → data/normals_1991_2020_extract.json (HDD, rainfall, humidex, cold days).
- ✅ A3 BC Assessment user guide PDF → data/; field positions confirmed. Property-tax report schema checked: no floor-area field.
- ✅ B Building footprints 2009 schema: has area_m2 and heights (fallback for floor area).
- ✅ B Issued building permits, seven address exports → sources/11, data/vancouver_permits_7sites.json. Site 515 W Hastings added.
- ✅ J All five library PDFs (Lygnerud & Werner; Wahlroos 2018; Ayuso-Virgili; Ion; Barroso 3rd ed.) → sources/10.
- ✅ K GWELLS export (well, lithology, screen, pump tests) and Nistad 2020 thesis → sources/10.
- ◇ K Grange Castle: link dead; optional, see below.
- ✅ 11 Oct: Alta Reg 117/2026 (full text; 1,600 MW pool is AESO, not statute) · Alberta offset handbooks v3.1–3.3 (EGDF schedule 0.49→0.34) · NRCan CEUD residential and commercial tables, BC and AB 2023 · Alberta Water Wells & GSHE Directive 2018 · GSHE fact sheets 2024/2025 · Guide to Groundwater Authorization 2023 · AUC Rule 012 (Table 1, all cells) · BC Hydro 2025 IRP Exhibit B-1 (LRMC $97/MWh, $300/kW-yr; 300 MW AI + 100 MW DC limits) · West End Substation CPCN application (feeder positions exhausted FY2027, WES July 2032). All in data/, all folded into the register.


## A. Unlocks whole branches of the tool

**⏳ 3. Vancouver gross floor area per parcel — the one item that still blocks a quantity**
- UBC Library data access: https://abacus.library.ubc.ca/dataset.xhtml?persistentId=hdl:11272.1/AB2/LAPUAB (BC Assessment data via Abacus). Abacus shows the file as Restricted with "Users may not request access" — that is by design: BC Assessment access is arranged by the Data Librarian, not self-service. Email **Jeremy Buhler, Data Librarian, UBC Library Research Commons (jeremy.buhler@ubc.ca)**, meet briefly, agree to the licence terms in writing; the file then unlocks for your CWL account (UBC Library notice: https://about.library.ubc.ca/?p=24468). Ask for the **Commercial** inventory extract (20200701_Commercial_Inventory_Extract.txt, 13 MB) (Abacus lists only Commercial and Residential; BC Assessment's own guide calls it the Non-Residential Inventory Extract) and the **Data Advice** if listed, for Vancouver; sign the terms. When it arrives, send the Vancouver file; I check it against the field positions in the user guide (19 Gross Building Area, 7/8 leasable, 6 storeys, 42 heating, 45 construction).

## B. Vancouver open data (schema tabs only; the API is robots-blocked)
- ✅ Sewer mains schema: effluent type, material, geometry only — no diameter or flow.
- ✅ Permits: 515 W Hastings exported (24 rows, site 7a); 308 E 5th has no permits (three searches).
- ✅ Energy and carbon report map: four sites found (reporting year 2025) → data/vancouver_energy_report.json.

## C. NRCan energy-use tables
- ✅ Residential Table 2 and Commercial Table 3, BC and AB (done 11 Oct; data/nrcan_ceud_latest.json).

## D. National Inventory Report 2026 (provincial electricity tables)
- ⏳ NIR 2026: Part 1 received 11 Oct (national table only, data/NIR_2026_Part1.pdf). Still need **Part 3** from the same UNFCCC Canada listing (provincial electricity-intensity tables), or the CSV equivalent from https://open.canada.ca/data/en/dataset/779c7bcf-4982-47eb-af1b-a33618a05e5b.

## E. BC Utilities Commission
- ✅ https://www.bcuc.com (done 11 Oct)
- ✅ Same site (done 11 Oct)

## F. Government of Alberta
- ✅ https://open.alberta.ca/publications/9781460141588 (done 11 Oct)
- ✅ https://open.alberta.ca/publications/ground-source-heat-exchange-systems-in-alberta (done 11 Oct)
- ✅ https://www.alberta.ca/groundwater-management (done 11 Oct)
- ✅ https://www.alberta.ca/alberta-emission-offset-system (done 11 Oct)
- ✅ https://kings-printer.alberta.ca (done 11 Oct)
- ☐ (deferred by J.B., 10 Oct) Edmonton water wells. The full AWWID download is a 2 GB Access database — don't use it. Instead: https://groundwater.alberta.ca/WaterWells/d/ → zoom to Edmonton until the scale reads 1:100,000 or closer → Find Water Wells → By Selection → rectangle tool → drag a box, export the results list → repeat for ~4 boxes (downtown/river valley first; townships T52–T53, ranges R24–R25, W4M cover the sites). Until then `ground` is Vancouver-only.
- ☐ https://www.aeso.ca/assets/Uploads/project-reporting/October-2026-Project-List.xlsx — ✅ done 10 Oct (data/aeso_project_list_oct2026_extract.json). Re-download monthly; the file name changes with the month.

## G. Alberta Utilities Commission
- ✅ https://www.auc.ab.ca/rules/ (done 11 Oct)

## H. Edmonton
- ⏳ Edmonton DDE: cover report and IIS02765 received 11 Oct. Still need, from the same 23 Jun 2025 Utility Committee item: **IIS02765 Attachment 4** (2025–2026 Utility Rate Filing — the $/GJ tariff), **Attachment 3** (business case), and **FCS02853 Attachment 1** (Fiscal Policy C631).

## I. Statistics Canada (one zip)
- ☐ https://www150.statcan.gc.ca/n1/tbl/csv/25100060-eng.zip — Table 25-10-0060 household energy consumption. Just download the zip; it confirms the 81.2 / 121.8 GJ figures from the primary.

## K. Worth opening in your own browser (JavaScript-only pages)
- ◇ Grange Castle (Ireland) — the direct link I gave (planning.southdublin.ie/Home/ApplicationDetails/SD20A/0121) returns 404; the reference may be wrong or the portal does not deep-link. Two routes:
  1. SDCC planning search: https://planning.southdublin.ie → "Search" → enter the file reference (try SD20A/0121; if nothing, search by location "Grange Castle" and applicant "Microsoft" / "Amazon" / "Google", years 2019–2022) → open the application → "Documents" → download the EIAR chapter titled "Noise and Vibration".
  2. An Bord Pleanála inspector's reports are public PDFs and summarise the noise assessment (limits and predicted receptor levels, not plant sound power): e.g. ABP-305948-19 (SDCC ref SD19A/0042, data centre west of Grange Castle Business Park) https://www.pleanala.ie/anbordpleanala/media/abp/cases/reports/305/r305948.pdf pp.39–40.
  Optional: the register already holds filed plant sound-power tables from Olds AB, Burlington ON and three UK Environment Agency filings (sources/08), which cover the same need.
- ☐ https://ens.dk/en/analyses-and-statistics/technology-data-generation-electricity-and-district-heating — download the **Excel data sheet** for the catalogue; the heat-pump rows carry "Space requirement, 1000 m²/MW".

## L. Operators and filings (form-gated or too long for the tool)
- ☐ https://cologix.com/resources/spec-sheets/van1-data-center-spec-sheet/ and …/van4-data-center-spec-sheet/ — request the PDFs.
- ☐ Equinix FY2024 10-K, Item 7 (MD&A), https://www.sec.gov/Archives/edgar/data/1101239/000162828025005126/eqix-20241231.htm — open in the browser, Ctrl-F "cabinet" and screenshot the table of cabinet capacity and utilisation by region (Americas row). The only public operator utilisation figure; the tool can't read past the first ~100k characters of the filing.

## M. Check back monthly
- https://app.bchydro.com/accounts-billing/electrical-connections/large-load/emerging-industries-connections.html — 2026 Call for Demand results (as of 10 Oct: 15 applications, ~800 MW, outcome deferred past the election transition).
- https://aesoengage.aeso.ca/pre-engagement-phase-ii-large-load-integration — final BYOG process and any allocations.
- https://www.enmax.com/system-resources/load-capacity-map — not our city, but if BC Hydro or EPCOR publish an equivalent (BC Hydro said "next year" in Mar 2025 press), it replaces the "stop and study" headroom verdict.
