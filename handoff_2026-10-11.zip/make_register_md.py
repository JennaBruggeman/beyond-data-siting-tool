#!/usr/bin/env python3
"""Regenerate formula_register.md from formula_register.json. Run: python3 make_register_md.py"""
import json, datetime, os
here=os.path.dirname(os.path.abspath(__file__))
r=json.load(open(os.path.join(here,'formula_register.json'),encoding='utf-8'))
Q={q['id']:q for q in r['quantities']}
STAGES=[('size','Size the facility'),('characterise','Characterise what it gives off and holds'),('prospect','Prospect the surroundings and quantify opportunities'),('test','Test the match'),('decide','Decide and account')]
def upstream(i,seen=None):
    seen=seen or set()
    if i not in Q or i in seen: return 100
    seen=seen|{i}; q=Q[i]
    vals=[q['conf']]
    for x in q['inputs']:
        if x=='*': vals.append(min(upstream(y,seen) for y in Q if y!=i))
        elif x in Q: vals.append(upstream(x,seen))
    return min(vals)
usedby={}
for c in r['conditions']:
    for x in c['quantities']: usedby.setdefault(x,[]).append(c['name'])
d=datetime.date.today().strftime('%-d %b %Y')
L=[f"# Beyond Data — formula register\n\nGenerated {d} from `formula_register.json` (the diagram reads the JSON; edit that, then run `make_register_md.py`).\n",
f"**Scale.** {r['meta']['confidence_scale']}\n", f"**Rule.** {r['meta']['rule']}\n", f"**Verification.** {r['meta']['verified']}\n",
f"**Counts.** {len(r['quantities'])} quantities · {len(r['conditions'])} conditions under 10 headings · {len(r['opportunity_quantities'])} opportunities quantified.\n",
"## Quantities\n", '"own" is the confidence of the quantity\'s own coefficient and source; "upstream" is the lowest confidence of anything feeding it.\n']
for sid,sname in STAGES:
    L.append(f"### {sname}\n\n| id | quantity | unit | formula | inputs | coefficients | sources | own | upstream | status | used by |\n|---|---|---|---|---|---|---|---|---|---|---|")
    for q in r['quantities']:
        if q['stage']!=sid: continue
        esc=lambda s:str(s).replace('|','∣')
        L.append(f"| `{q['id']}` | {esc(q['name'])} | {esc(q['unit'])} | {esc(q['formula'])} | {', '.join(q['inputs']) or '—'} | {esc(q['coef']) or '—'} | {', '.join(q['sources'])} | {q['conf']} | {upstream(q['id'])} | {esc(q['status'])} | {'; '.join(usedby.get(q['id'],[])) or '— (input to others)'} |")
    L.append("")
L.append("## Conditions (open list, from GP1 8 Oct 2026)\n\n| heading | condition | test | quantities | weakest |\n|---|---|---|---|---|")
for c in r['conditions']:
    w=min([upstream(x) for x in c['quantities'] if x in Q] or [0])
    L.append(f"| {c['heading']} | {c['name']} | {c['test'].replace('|','∣')} | {', '.join('`'+x+'`' for x in c['quantities'])} | {w} |")
L.append("\n## Opportunities and the quantities that size them\n")
for name,qs in r['opportunity_quantities'].items():
    w=min([upstream(x) for x in qs if x in Q] or [0])
    L.append(f"- **{name}**: {', '.join('`'+x+'`' for x in qs)} (weakest {w})")
L.append("\n## Sources\n")
if r['meta'].get('source_note'): L.append(r['meta']['source_note']+"\n")
for k,v in r['new_sources'].items(): L.append(f"- `{k}` — {v}")
L.append("\n## Remaining gaps (after two search passes, verification, hunts 9–10)\n")
for i,g in enumerate(r['meta'].get('gaps',[]),1): L.append(f"{i}. {g}")
open(os.path.join(here,'formula_register.md'),'w',encoding='utf-8').write('\n'.join(L)+'\n')
missing=sorted({x for q in r['quantities'] for x in q['inputs'] if x not in Q and x not in ('*',)})
print('written; non-quantity inputs:',missing)
